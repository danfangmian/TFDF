import argparse
from omegaconf import OmegaConf
from pytorch_lightning import Trainer
from pytorch_lightning.callbacks import EarlyStopping, ModelCheckpoint
import numpy as np
import pytorch_lightning as pl
import torch
from data_provider.datamodules import ForecastDataModule
from models.base import ForecastSolver


def load_config(path):
    conf = OmegaConf.load(path)
    dataset = conf.data
    data_conf = OmegaConf.load("configs/dataset_conf.yaml")
    conf.merge_with(data_conf[dataset])
    model_conf = OmegaConf.load(f"configs/models/{conf.model}.yaml")
    conf.merge_with(model_conf)
    if conf.features == "M":
        conf.c_in = conf.enc_in = conf.c_out = conf.dec_in = conf.num_vars
    elif conf.features == "S":
        conf.c_in = conf.enc_in = conf.c_out = conf.dec_in = 1
    else:
        conf.c_in = conf.enc_in = conf.dec_in = conf.num_vars
        conf.c_out = 1
    return conf


def build_trainer(config):
    callbacks = []
    if config.early_stopping.enable:
        callbacks.append(
            EarlyStopping(
                log_rank_zero_only=True,
                **config.early_stopping.params,
            )
        )
    if config.model_checkpoint.enable:
        callbacks.append(ModelCheckpoint(**config.model_checkpoint.params))
    trainer = Trainer(callbacks=callbacks, **config.trainer.params)
    return trainer


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="config")
    parser.add_argument("--config_path", type=str, default="configs/conf.yaml")
    args = parser.parse_args()
    config_path = args.config_path
    config = load_config(config_path)
    times = config.get("times", 1)
    seeds = [np.random.randint(0, 1000) for _ in range(times)]
    results = []
    for i in range(times):
        # seed = config.random_seed
        # if seed is None:
        #     seed = np.random.randint(0, 5000)
        #     print("Using seed:", seed)
        print("=================experiment %d=================" % (i+1))
        seed = seeds[i]
        print(f"Using seed: {seed}")
        pl.seed_everything(seed=seed, workers=True)
        trainer = build_trainer(config)
        data_module = ForecastDataModule(config)
        solver = ForecastSolver(config)
        trainer.fit(model=solver, datamodule=data_module)
        result = trainer.test(model=solver, datamodule=data_module, ckpt_path="best")[0]
        results.append(result)
    if times > 1:
        # 计算所有指标的平均值
        metrics_mean = {}
        for metric in results[0].keys():
            values = [r[metric] for r in results]
            metrics_mean[metric] = np.mean(values)
            
        print("\n平均指标结果:")
        for metric, mean_val in metrics_mean.items():
            print(f"{metric}: {mean_val:.4f}")