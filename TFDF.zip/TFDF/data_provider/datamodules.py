from pytorch_lightning.utilities.types import TRAIN_DATALOADERS
from data_provider.datasets import (
    ETT_Hour_Dataset,
    ETT_Minute_Dataset,
    Custom_Dataset,
    Solar_Dataset,

)
from torch.utils.data import DataLoader
from pytorch_lightning import LightningDataModule

forecast_datasets = {
    "ETTh1": ETT_Hour_Dataset,
    "ETTh2": ETT_Hour_Dataset,
    "ETTm1": ETT_Minute_Dataset,
    "ETTm2": ETT_Minute_Dataset,
    "custom": Custom_Dataset,
    "solar": Solar_Dataset,
}

# def data_provider(args, flag):
#     Data = data_dict[args.dataset]
#     timeenc = 0 if args.embed != "timeF" else 1

#     shuffle_flag = False if flag == "test" else True
#     drop_last = True
#     batch_size = args.batch_size
#     freq = args.freq

#     if args.task_name == "anomaly_detection":
#         drop_last = False
#         data_set = Data(
#             args=args,
#             root_path=args.root_path,
#             win_size=args.seq_len,
#             flag=flag,
#         )
#         print(flag, len(data_set))
#         data_loader = DataLoader(
#             data_set,
#             batch_size=batch_size,
#             shuffle=shuffle_flag,
#             num_workers=args.num_workers,
#             drop_last=drop_last,
#         )
#         return data_set, data_loader
#     else:
#         if args.dataset == "m4":
#             drop_last = False
#         data_set = Data(
#             args=args,
#             root_path=args.root_path,
#             data_path=args.data_path if args.dataset == 'm4' else None,
#             flag=flag,
#             size=[args.seq_len, args.label_len, args.pred_len],
#             features=args.features,
#             target=args.target,
#             timeenc=timeenc,
#             freq=freq if args.dataset == 'm4' else None,
#             seasonal_patterns=args.seasonal_patterns,
#         )
#         data_loader = DataLoader(
#             data_set,
#             batch_size=batch_size,
#             shuffle=shuffle_flag,
#             num_workers=args.num_workers,
#             drop_last=drop_last,
#         )
#         return data_set, data_loader


class ForecastDataModule(LightningDataModule):
    def __init__(self, args):
        super().__init__()
        self.args = args

    def setup(self, stage: str) -> None:
        Dataset = forecast_datasets[self.args.dataset]
        timeenc = 0 if self.args.embed != "timeF" else 1
        if stage == "fit":
            self.train_dataset = Dataset(
                args=self.args,
                root_path=self.args.root_path,
                data_path=self.args.data_path,
                flag='train',
                size=[
                    self.args.seq_len,
                    self.args.label_len,
                    self.args.pred_len,
                ],
                features=self.args.features,
                target=self.args.target,
                timeenc=timeenc,
                freq=self.args.freq,
                scale=self.args.scale,
                seasonal_patterns=self.args.seasonal_patterns,
            )
            self.val_dataset = Dataset(
                args=self.args,
                root_path=self.args.root_path,
                data_path=self.args.data_path,
                flag='val',
                size=[
                    self.args.seq_len,
                    self.args.label_len,
                    self.args.pred_len,
                ],
                features=self.args.features,
                target=self.args.target,
                timeenc=timeenc,
                freq=self.args.freq,
                scale=self.args.scale,
                seasonal_patterns=self.args.seasonal_patterns,
            )
        if stage == "test":
            self.test_dataset = Dataset(
                args=self.args,
                root_path=self.args.root_path,
                data_path=self.args.data_path,
                flag='test',
                size=[
                    self.args.seq_len,
                    self.args.label_len,
                    self.args.pred_len,
                ],
                features=self.args.features,
                target=self.args.target,
                timeenc=timeenc,
                freq=self.args.freq,
                scale=self.args.scale,
                seasonal_patterns=self.args.seasonal_patterns,
            )

    def train_dataloader(self):
        return DataLoader(
            dataset=self.train_dataset,
            batch_size=self.args.batch_size,
            shuffle=True,
            num_workers=self.args.num_workers,
            drop_last=False,
            persistent_workers=True,
        )

    def val_dataloader(self):
        return DataLoader(
            dataset=self.val_dataset,
            batch_size=self.args.batch_size,
            shuffle=False,
            num_workers=self.args.num_workers,
            drop_last=False,
            persistent_workers=True,
        )

    def test_dataloader(self):
        return DataLoader(
            dataset=self.test_dataset,
            batch_size=self.args.batch_size,
            shuffle=False,
            num_workers=self.args.num_workers,
            drop_last=False,
            persistent_workers=True,
        )