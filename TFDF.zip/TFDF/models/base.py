import datetime
from importlib import import_module
import os
from omegaconf import OmegaConf
import pytorch_lightning as pl
from abc import ABC, abstractmethod

import torch
import torch.nn as nn
from utils.metrics.np import metric
from utils.metrics.t import MSE, SignalDecayLoss, MAE
import numpy as np
import matplotlib.pyplot as plt
from torch.nn import SmoothL1Loss


class ForecastModel(nn.Module, ABC):
    def __init__(self, config):
        super().__init__()
        self.pred_len = config.pred_len
        self._init_model(config)

    @abstractmethod
    def _init_model(self, config):
        pass

    @abstractmethod
    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        pass

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len :, :]  # [B, L, D]


class BaseSolver(pl.LightningModule, ABC):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self._init_loss_fn()
        self._init_model()
        if self.config.trainer.params.logger:
            self.save_hyperparameters(self.config)

    @abstractmethod
    def _init_model(self, *args, **kwargs):
        pass

    @abstractmethod
    def _init_loss_fn(self, *args, **kwargs):
        pass

    @abstractmethod
    def forward(self, *args, **kwargs):
        pass

    def configure_optimizers(self):
        optimizer_conf = self.config.get("optimizer", {})
        scheduler_conf = self.config.get("scheduler", {})
        o_type = optimizer_conf.get("type", "Adam")
        o_params = optimizer_conf.get("params", {"lr": 1e-3})
        o_class = getattr(torch.optim, o_type, None)
        if o_class is None:
            raise ValueError(f"Unsupported optimizer type: {o_type}")
        optimizer = o_class(self.parameters(), **o_params)
        if scheduler_conf:
            s_type = scheduler_conf.get("type", "StepLR")
            s_params = scheduler_conf.get("params", {"step": 1, "gamma": 0.5})
            s_class = getattr(torch.optim.lr_scheduler, s_type, None)
            if s_class is None:
                raise ValueError(f"Unsupported scheduler type: {s_type}")
            scheduler = s_class(optimizer, **s_params)
            return {
                "optimizer": optimizer,
                "lr_scheduler": {
                    "scheduler": scheduler,
                    "interval": scheduler_conf.get("interval", "epoch"),
                    "frequency": scheduler_conf.get("frequency", 1),
                },
            }
        return optimizer


class ForecastSolver(BaseSolver):
    def __init__(self, config):
        super().__init__(config)
        self.f_dim = -1 if self.config.features == "MS" else 0
        self.test_batches = []

    def _init_loss_fn(self):
        losses = {
            "mse": MSE,
            "mae": MAE,
            "signal_decay": SignalDecayLoss,
            "smooth_l1": SmoothL1Loss,
        }
        train_loss_name = self.config.get("train_loss", "mse").lower()
        val_loss_name = self.config.get("val_loss", "mse").lower()
        self.train_loss_fn = losses.get(train_loss_name, MSE)()
        self.val_loss_fn = losses.get(val_loss_name, MSE)()

    def _init_model(self):
        self.model_name = self.config.model
        module_path = f"models.forecast.{self.model_name}"
        model = getattr(import_module(module_path), "Model")(self.config).float()
        print("Using model `" + self.model_name + "` for forecasting")
        self.model = model

    def _prepare_decoder_input(self, batch_y):
        dec_inp = torch.zeros_like(batch_y[:, -self.config.pred_len :, :]).float()
        dec_inp = torch.cat(
            [batch_y[:, : self.config.label_len, :], dec_inp], dim=1
        ).to(self.device)
        return dec_inp

    def forward(self, batch_x, batch_y, batch_x_mark, batch_y_mark):
        dec_input = self._prepare_decoder_input(batch_y)
        output = self.model(batch_x, batch_x_mark, dec_input, batch_y_mark)
        return output

    def training_step(self, batch, batch_idx):
        batch_x, batch_y, batch_x_mark, batch_y_mark = map(lambda x: x.float(), batch)
        output = self(batch_x, batch_y, batch_x_mark, batch_y_mark)
        output = output[:, :, self.f_dim :]
        batch_y = batch_y[:, -self.config.pred_len :, self.f_dim :]
        loss = self.train_loss_fn(output, batch_y)
        self.log(
            "train_loss",
            loss,
            on_step=True,
            on_epoch=True,
            prog_bar=True,
            logger=True,
            sync_dist=True,
            rank_zero_only=True,
        )
        return loss

    def validation_step(self, batch, batch_idx):
        batch_x, batch_y, batch_x_mark, batch_y_mark = map(lambda x: x.float(), batch)
        output = self(batch_x, batch_y, batch_x_mark, batch_y_mark)
        output = output[:, :, self.f_dim :]
        batch_y = batch_y[:, -self.config.pred_len :, self.f_dim :]
        val_loss = self.val_loss_fn(output, batch_y)
        self.log(
            "val_loss",
            val_loss,
            on_step=False,
            on_epoch=True,
            prog_bar=True,
            logger=True,
            sync_dist=True,
            rank_zero_only=True,
        )
        return val_loss

    def test_step(self, batch, batch_idx):
        batch_x, batch_y, batch_x_mark, batch_y_mark = map(lambda x: x.float(), batch)
        output = self(batch_x, batch_y, batch_x_mark, batch_y_mark)
        output = output.detach().cpu()
        batch_y = batch_y.detach().cpu()[:, -self.config.pred_len :, :]
        batch_x = batch_x.detach().cpu()
        if self.config.scale and self.config.inverse:
            if self.config.dataset != "custom":
                output = output.numpy()
                batch_y = batch_y.numpy()
                batch_x = batch_x.numpy()
            inv_transform_fn = self.trainer.test_dataloaders.dataset.inverse_transform
            shape = output.shape
            output = inv_transform_fn(output.reshape(shape[0] * shape[1], -1)).reshape(
                shape
            )
            batch_y = inv_transform_fn(
                batch_y.reshape(shape[0] * shape[1], -1)
            ).reshape(shape)
            shape = batch_x.shape
            batch_x = inv_transform_fn(
                batch_x.reshape(shape[0] * shape[1], -1)
            ).reshape(shape)
        output, batch_y = output[:, :, self.f_dim :], batch_y[:, :, self.f_dim :]
        batch_x = batch_x[:, :, self.f_dim :]
        if not self.config.inverse or (
            self.scale and self.config.inverse and self.config.dataset == "custom"
        ):
            output = output.numpy()
            batch_y = batch_y.numpy()
            batch_x = batch_x.numpy()
        self.test_batches.append((output, batch_y, batch_x))

    def on_test_epoch_end(self):
        preds, targets, hists = [], [], []
        for batch in self.test_batches:
            pred, target, history = batch
            preds.append(pred)
            targets.append(target)
            hists.append(history)
        self.test_batches.clear()
        preds = np.concatenate(preds, axis=0)
        targets = np.concatenate(targets, axis=0)
        hists = np.concatenate(hists, axis=0)
        metrics_result = metric(targets, preds, metrics=self.config.test_metrics)
        self.log_dict(metrics_result)
        if self.config.save_test_result:
            if self.logger is not None:
                output_dir = os.path.join(self.logger.log_dir, "test_result")
            else:
                ts = datetime.datetime.now().strftime(
                    f"%Y-%m-%d_%H:%M:%S_{self.model_name}"
                )
                output_dir = f"./test_result/{ts}"
            os.makedirs(os.path.join(output_dir, "visual"), exist_ok=True)
            if not self.logger:
                OmegaConf.save(self.config, os.path.join(output_dir, "hparams.yaml"))
            np.savez(
                os.path.join(output_dir, "result.npz"),
                preds=preds,
                targets=targets,
                hists=hists,
            )
            visual_stategy = self.config.get("visual_stategy", "step")
            if visual_stategy == "step":
                idxs = list(range(0, len(preds), self.config.get("visual_step", 100)))
            elif visual_stategy == "random":
                idxs = np.random.choice(len(preds), self.config.get("visual_num", 100))
            elif visual_stategy == "lowest":
                preds_for_cal = preds[:, :: self.config.pred_len, -1]
                targets_for_cal = targets[:, :: self.config.pred_len, -1]
                errors = np.mean((preds_for_cal - targets_for_cal) ** 2, axis=-1)
                lowest_idx = np.argsort(errors)[: self.config.get("visual_num", 10)]
                idxs = lowest_idx * self.config.pred_len
            else:
                idxs = self.config.visual_idxs
            for i in idxs:
                self.visual(
                    target=targets[i, :, -1],
                    pred=preds[i, :, -1],
                    history=hists[i, :, -1],
                    name=os.path.join(output_dir, "visual", f"test_result_{i}.pdf"),
                )
            self.print("Save test results in {}".format(output_dir))
        if not self.config.model_checkpoint.save:
            model_path = self.trainer.checkpoint_callback.best_model_path
            if os.path.exists(model_path):
                os.remove(model_path)
    

    @staticmethod
    def visual(target, pred, history, name="./pic/test.pdf"):
        plt.figure()
        # 绘制历史值
        plt.plot(list(range(len(history))), history, label="Input Data", linewidth=2)
        pred = np.concatenate(([history[-1]], pred), axis=0)
        target = np.concatenate(([history[-1]], target), axis=0)
        plt.plot(
            list(range(len(history) - 1, len(history) + len(pred) - 1)),
            pred,
            label="Prediction",
            linewidth=2,
        )
        plt.plot(
            list(range(len(history) - 1, len(history) + len(target) - 1)),
            target,
            label="Ground Truth",
            linewidth=2,
            color="grey",
        )
        plt.legend()
        plt.grid()
        plt.savefig(name, bbox_inches="tight")
        plt.close()
