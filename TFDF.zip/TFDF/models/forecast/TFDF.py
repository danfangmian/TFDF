from models.base import ForecastModel
import torch
import torch.nn as nn
import torch.nn.functional as F
from pytorch_wavelets import DWT1DForward, DWT1DInverse
import math

class DataEmbedding_inverted(nn.Module):
    """
    数据嵌入层（倒置）

    对输入数据进行线性变换，并应用dropout。

    参数:
        c_in (int): 输入通道数。
        d_model (int): 嵌入维度。
        embed_type (str): 嵌入类型，默认为'fixed'。
        freq (str): 时间频率，默认为'h'（小时）。
        dropout (float): Dropout率，默认为0.1。

    输入:
        x (torch.Tensor): 输入数据张量，形状为[batch_size, seq_len, c_in]
        x_mark (torch.Tensor): 时间标记张量，形状为[batch_size, seq_len, time_features]，可选

    输出:
        torch.Tensor: 嵌入后的张量，形状为[batch_size, seq_len, d_model]
    """

    def __init__(
        self,
        c_in: int,
        d_model: int,
        embed_type: str = "fixed",
        freq: str = "h",
        dropout: float = 0.1,
    ):
        super(DataEmbedding_inverted, self).__init__()
        self.value_embedding = nn.Linear(c_in, d_model)
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, x: torch.Tensor, x_mark: torch.Tensor = None) -> torch.Tensor:
        x = x.permute(0, 2, 1)  # [batch_size, c_in, seq_len]
        if x_mark is None:
            x = self.value_embedding(x)
        else:
            x = self.value_embedding(torch.cat([x, x_mark.permute(0, 2, 1)], 1))
        return self.dropout(x)  # [batch_size, c_in, d_model]


class Encoder(nn.Module):
    """
    编码器，由多个编码器层和卷积层组成。

    参数:
        attn_layers (list): 注意力层的列表。
        conv_layers (list, 可选): 卷积层的列表。默认为 None。
        norm_layer (nn.Module, 可选): 归一化层。默认为 None。
    """

    def __init__(self, attn_layers, conv_layers=None, norm_layer=None):
        super(Encoder, self).__init__()
        self.attn_layers = nn.ModuleList(attn_layers)
        self.conv_layers = (
            nn.ModuleList(conv_layers) if conv_layers is not None else None
        )
        self.norm = norm_layer

    def forward(
        self,
        x: torch.Tensor,
        attn_mask: torch.Tensor = None,
        tau: torch.Tensor = None,
        delta: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        前向传播。

        参数:
            x (torch.Tensor): 输入张量，形状为 (batch_size, seq_len, d_model)。
            attn_mask (torch.Tensor, 可选): 注意力掩码。默认为 None。
            tau (torch.Tensor, 可选): 可选参数。默认为 None。
            delta (torch.Tensor, 可选): 可选参数。默认为 None。

        返回:
            torch.Tensor: 编码后的输出张量。
            list: 注意力张量的列表。
        """
        attns = []
        if self.conv_layers is not None:
            for i, (attn_layer, conv_layer) in enumerate(
                zip(self.attn_layers, self.conv_layers)
            ):
                delta = delta if i == 0 else None
                x, attn = attn_layer(x, attn_mask=attn_mask, tau=tau, delta=delta)
                x = conv_layer(x)
                attns.append(attn)
            x, attn = self.attn_layers[-1](x, tau=tau, delta=None)
            attns.append(attn)
        else:
            for attn_layer in self.attn_layers:
                x, attn = attn_layer(x, attn_mask=attn_mask, tau=tau, delta=delta)
                attns.append(attn)

        if self.norm is not None:
            x = self.norm(x)

        return x, attns


class EncoderLayer(nn.Module):
    """
    编码器层，包含自注意力、卷积层和归一化。

    参数:
        attention (nn.Module): 自注意力模块。
        d_model (int): 输入的维度。
        d_ff (int, 可选): 前馈网络的维度。默认为 4 * d_model。
        dropout (float, 可选): Dropout 率。默认为 0.1。
        activation (str, 可选): 激活函数。可以是 'relu' 或 'gelu'。默认为 'relu'。
    """

    def __init__(
        self,
        attention: nn.Module,
        d_model: int,
        d_ff: int = None,
        dropout: float = 0.1,
        activation: str = "relu",
    ):
        super(EncoderLayer, self).__init__()
        d_ff = d_ff or 4 * d_model
        self.attention = attention
        self.conv1 = nn.Conv1d(in_channels=d_model, out_channels=d_ff, kernel_size=1)
        self.conv2 = nn.Conv1d(in_channels=d_ff, out_channels=d_model, kernel_size=1)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = F.relu if activation == "relu" else F.gelu

    def forward(
        self,
        x: torch.Tensor,
        attn_mask: torch.Tensor = None,
        tau: torch.Tensor = None,
        delta: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        前向传播。

        参数:
            x (torch.Tensor): 输入张量，形状为 (batch_size, seq_len, d_model)。
            attn_mask (torch.Tensor, 可选): 注意力掩码。默认为 None。
            tau (torch.Tensor, 可选): 可选参数。默认为 None。
            delta (torch.Tensor, 可选): 可选参数。默认为 None。

        返回:
            torch.Tensor: 经过注意力、卷积和归一化后的输出张量。
        """
        new_x, attn = self.attention(x, x, x, attn_mask=attn_mask, tau=tau, delta=delta)
        x = x + self.dropout(new_x)

        y = x = self.norm1(x)
        y = self.dropout(self.activation(self.conv1(y.transpose(-1, 1))))
        y = self.dropout(self.conv2(y).transpose(-1, 1))

        return self.norm2(x + y), attn


class GAR(nn.Module):
    def __init__(self, d_series, d_core):
        super(GAR, self).__init__()
        """
        GAR Aggregate-Redistribute Module
        """

        self.gen1 = nn.Linear(d_series, d_series)
        self.gen2 = nn.Linear(d_series, d_core)
        self.gen3 = nn.Linear(d_series + d_core, d_series)
        self.gen4 = nn.Linear(d_series, d_series)

    def forward(self, input, *args, **kwargs):
        batch_size, channels, d_series = input.shape

        # set FFN
        combined_mean = F.gelu(self.gen1(input))
        combined_mean = self.gen2(combined_mean)

        # stochastic pooling
        if self.training:
            ratio = F.softmax(combined_mean, dim=1)
            ratio = ratio.permute(0, 2, 1)
            ratio = ratio.reshape(-1, channels)
            indices = torch.multinomial(ratio, 1)
            indices = indices.view(batch_size, -1, 1).permute(0, 2, 1)
            combined_mean = torch.gather(combined_mean, 1, indices)
            combined_mean = combined_mean.repeat(1, channels, 1)
        else:
            weight = F.softmax(combined_mean, dim=1)
            combined_mean = torch.sum(
                combined_mean * weight, dim=1, keepdim=True
            ).repeat(1, channels, 1)

        # mlp fusion
        combined_mean_cat = torch.cat([input, combined_mean], -1)
        combined_mean_cat = F.gelu(self.gen3(combined_mean_cat))
        combined_mean_cat = self.gen4(combined_mean_cat)
        output = combined_mean_cat

        return output, None


class Decomposition(nn.Module):
    def __init__(
        self,
        input_length=[],
        pred_length=[],
        wavelet_name=[],
        level=[],
        batch_size=[],
        channel=[],
        d_model=[],
        tfactor=[],
        dfactor=[],
        no_decomposition=[],
    ):
        super(Decomposition, self).__init__()
        self.input_length = input_length
        self.pred_length = pred_length
        self.wavelet_name = wavelet_name
        self.level = level
        self.batch_size = batch_size
        self.channel = channel
        self.d_model = d_model
        self.no_decomposition = no_decomposition
        self.eps = 1e-5

        self.dwt = DWT1DForward(wave=self.wavelet_name, J=self.level)
        self.idwt = DWT1DInverse(wave=self.wavelet_name)

        self.input_w_dim = (
            self._dummy_forward(self.input_length)
            if not self.no_decomposition
            else [self.input_length]
        )  # length of the input seq after decompose
        self.pred_w_dim = (
            self._dummy_forward(self.pred_length)
            if not self.no_decomposition
            else [self.pred_length]
        )  # required length of the pred seq after decom

        self.tfactor = tfactor
        self.dfactor = dfactor
        #################################
        self.affine = True
        #################################

        if self.affine:
            self._init_params()

    def transform(self, x):
        # input: x shape: batch, channel, seq
        if not self.no_decomposition:
            yl, yh = self._wavelet_decompose(x)
        else:
            yl, yh = x, []  # no decompose: returning the same value in yl
        return yl, yh

    def inv_transform(self, yl, yh):
        if not self.no_decomposition:
            x = self._wavelet_reverse_decompose(yl, yh)
        else:
            x = yl  # no decompose: returning the same value in x
        return x

    def _dummy_forward(self, input_length):
        dummy_x = torch.ones((self.batch_size, self.channel, input_length))
        yl, yh = self.dwt(dummy_x)
        l = []
        l.append(yl.shape[-1])
        for i in range(len(yh)):
            l.append(yh[i].shape[-1])
        return l

    def _init_params(self):
        self.affine_weight = nn.Parameter(torch.ones((self.level + 1, self.channel)))
        self.affine_bias = nn.Parameter(torch.zeros((self.level + 1, self.channel)))

    def _wavelet_decompose(self, x):
        # input: x shape: batch, channel, seq
        yl, yh = self.dwt(x)

        if self.affine:
            yl = yl.transpose(1, 2)  # batch, seq, channel
            yl = yl * self.affine_weight[0]
            yl = yl + self.affine_bias[0]
            yl = yl.transpose(1, 2)  # batch, channel, seq
            for i in range(self.level):
                yh_ = yh[i].transpose(1, 2)  # batch, seq, channel
                yh_ = yh_ * self.affine_weight[i + 1]
                yh_ = yh_ + self.affine_bias[i + 1]
                yh[i] = yh_.transpose(1, 2)  # batch, channel, seq

        return yl, yh

    def _wavelet_reverse_decompose(self, yl, yh):
        if self.affine:
            yl = yl.transpose(1, 2)  # batch, seq, channel
            yl = yl - self.affine_bias[0]
            yl = yl / (self.affine_weight[0] + self.eps)
            yl = yl.transpose(1, 2)  # batch, channel, seq
            for i in range(self.level):
                yh_ = yh[i].transpose(1, 2)  # batch, seq, channel
                yh_ = yh_ - self.affine_bias[i + 1]
                yh_ = yh_ / (self.affine_weight[i + 1] + self.eps)
                yh[i] = yh_.transpose(1, 2)  # batch, channel, seq

        x = self.idwt((yl, yh))
        return x  # shape: batch, channel, seq


class weighted_moving_avg(nn.Module):
    def __init__(
        self,
        kernel_size: int = 25,
        weight_shared: bool = True,
        c_in: int = 1,
        learnable: bool = True,
        sigma: float = 1.0,
    ) -> None:
        super().__init__()
        self.kernel_size = kernel_size
        self.weight_shared = weight_shared
        self.c_in = c_in
        self.learnable = learnable
        self.sigma = sigma

        if self.weight_shared:
            self.conv = nn.Conv1d(
                1,
                1,
                kernel_size=kernel_size,
                stride=1,
                padding=int(kernel_size // 2),
                padding_mode="replicate",
                bias=True,
            )
        else:
            self.conv = nn.Conv1d(
                c_in,
                c_in,
                kernel_size=kernel_size,
                stride=1,
                padding=int(kernel_size // 2),
                padding_mode="replicate",
                bias=True,
                groups=c_in,
            )
            self.__init_weights(self.conv)

    def __init_weights(self, conv):
        kernel_size_half = self.kernel_size // 2
        weights = torch.zeros(1, 1, self.kernel_size)
        for i in range(self.kernel_size):
            weights[0, 0, i] = math.exp(
                -((i - kernel_size_half) ** 2) / (2 * self.sigma**2)
            )
        weights = F.softmax(weights, dim=-1)
        if self.weight_shared:
            conv.weight.data = weights
        else:
            weights = weights.repeat(self.c_in, 1, 1)  # 复制权重，适应多个通道
            conv.weight.data = weights
        conv.bias.data.fill_(0.0)
        if not self.learnable:
            conv.weight.requires_grad = False
            conv.bias.requires_grad = False

    def forward(self, x: torch.Tensor):
        B, L, N = x.size()
        if self.weight_shared:
            x = x.permute(0, 2, 1).reshape(B * N, 1, L)
            x = self.conv(x)
            x = x.reshape(B, N, L).permute(0, 2, 1)
        else:
            x = self.conv(x.permute(0, 2, 1))
            x = x.permute(0, 2, 1)
        return x


class weighted_series_decomp(nn.Module):
    def __init__(
        self,
        kernel_size: int = 25,
        weight_shared: bool = True,
        c_in: int = 1,
        learnable: bool = True,
        sigma: float = 1.0,
    ):
        super().__init__()
        self.moving_avg = weighted_moving_avg(
            kernel_size, weight_shared, c_in, learnable, sigma
        )

    def forward(self, x: torch.Tensor):
        # [B, T, N]
        moving_mean = self.moving_avg(x)
        res = x - moving_mean
        return res, moving_mean


class TokenMixer(nn.Module):
    def __init__(
        self,
        input_seq=[],
        batch_size=[],
        channel=[],
        pred_seq=[],
        dropout=[],
        factor=[],
        d_model=[],
    ):
        super(TokenMixer, self).__init__()
        self.input_seq = input_seq
        self.batch_size = batch_size
        self.channel = channel
        self.pred_seq = pred_seq
        self.dropout = dropout
        self.factor = factor
        self.d_model = d_model

        self.dropoutLayer = nn.Dropout(self.dropout)
        self.layers = nn.Sequential(
            nn.Linear(self.input_seq, self.pred_seq * self.factor),
            nn.GELU(),
            nn.Dropout(self.dropout),
            nn.Linear(self.pred_seq * self.factor, self.pred_seq),
        )

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.layers(x)
        x = x.transpose(1, 2)
        return x


class Mixer(nn.Module):
    def __init__(
        self,
        input_seq=[],
        out_seq=[],
        batch_size=[],
        channel=[],
        d_model=[],
        dropout=[],
        tfactor=[],
        dfactor=[],
    ):
        super(Mixer, self).__init__()
        self.input_seq = input_seq
        self.pred_seq = out_seq
        self.batch_size = batch_size
        self.channel = channel
        self.d_model = d_model
        self.dropout = dropout
        self.tfactor = tfactor  # expansion factor for patch mixer
        self.dfactor = dfactor  # expansion factor for embedding mixer

        self.tMixer = TokenMixer(
            input_seq=self.input_seq,
            batch_size=self.batch_size,
            channel=self.channel,
            pred_seq=self.pred_seq,
            dropout=self.dropout,
            factor=self.tfactor,
            d_model=self.d_model,
        )
        self.dropoutLayer = nn.Dropout(self.dropout)
        self.norm1 = nn.BatchNorm2d(self.channel)
        self.norm2 = nn.BatchNorm2d(self.channel)

        self.embeddingMixer = nn.Sequential(
            nn.Linear(self.d_model, self.d_model * self.dfactor),
            nn.GELU(),
            nn.Dropout(self.dropout),
            nn.Linear(self.d_model * self.dfactor, self.d_model),
        )

    def forward(self, x):
        """
        Parameters
        ----------
        x : input: [Batch, Channel, Patch_number, d_model]

        Returns
        -------
        x: output: [Batch, Channel, Patch_number, d_model]

        """
        x = self.norm1(x)
        x = x.permute(0, 3, 1, 2)
        x = self.dropoutLayer(self.tMixer(x))
        x = x.permute(0, 2, 3, 1)
        x = self.norm2(x)
        x = x + self.dropoutLayer(self.embeddingMixer(x))
        return x


class ResolutionBranch(nn.Module):
    def __init__(
        self,
        input_seq=[],
        pred_seq=[],
        batch_size=[],
        channel=[],
        d_model=[],
        dropout=[],
        embedding_dropout=[],
        tfactor=[],
        dfactor=[],
        patch_len=[],
        patch_stride=[],
    ):
        super(ResolutionBranch, self).__init__()
        self.input_seq = input_seq
        self.pred_seq = pred_seq
        self.batch_size = batch_size
        self.channel = channel
        self.d_model = d_model
        self.dropout = dropout
        self.embedding_dropout = embedding_dropout
        self.tfactor = tfactor
        self.dfactor = dfactor
        self.patch_len = patch_len
        self.patch_stride = patch_stride
        self.patch_num = int((self.input_seq - self.patch_len) / self.patch_stride + 2)

        self.patch_norm = nn.BatchNorm2d(self.channel)
        self.patch_embedding_layer = nn.Linear(
            self.patch_len, self.d_model
        )  # shared among all channels
        self.mixer1 = Mixer(
            input_seq=self.patch_num,
            out_seq=self.patch_num,
            batch_size=self.batch_size,
            channel=self.channel,
            d_model=self.d_model,
            dropout=self.dropout,
            tfactor=self.tfactor,
            dfactor=self.dfactor,
        )
        self.mixer2 = Mixer(
            input_seq=self.patch_num,
            out_seq=self.patch_num,
            batch_size=self.batch_size,
            channel=self.channel,
            d_model=self.d_model,
            dropout=self.dropout,
            tfactor=self.tfactor,
            dfactor=self.dfactor,
        )
        self.norm = nn.BatchNorm2d(self.channel)
        self.dropoutLayer = nn.Dropout(self.embedding_dropout)
        self.head = nn.Sequential(
            nn.Flatten(start_dim=-2, end_dim=-1),
            nn.Linear(self.patch_num * self.d_model, self.pred_seq),
        )

    def forward(self, x):
        """
        Parameters
        ----------
        x : input coefficient series: [Batch, channel, length_of_coefficient_series]

        Returns
        -------
        out : predicted coefficient series: [Batch, channel, length_of_pred_coeff_series]
        """

        x_patch = self.do_patching(x)
        x_patch = self.patch_norm(x_patch)
        x_emb = self.dropoutLayer(self.patch_embedding_layer(x_patch))

        out = self.mixer1(x_emb)
        res = out
        out = res + self.mixer2(out)
        out = self.norm(out)

        out = self.head(out)
        return out

    def do_patching(self, x):
        x_end = x[:, :, -1:]
        x_padding = x_end.repeat(1, 1, self.patch_stride)
        x_new = torch.cat((x, x_padding), dim=-1)
        x_patch = x_new.unfold(
            dimension=-1, size=self.patch_len, step=self.patch_stride
        )
        return x_patch


class WPMixerCore(nn.Module):
    def __init__(
        self,
        input_length=[],
        pred_length=[],
        wavelet_name=[],
        level=[],
        batch_size=[],
        channel=[],
        d_model=[],
        d_core=[],
        dropout=[],
        embedding_dropout=[],
        tfactor=[],
        dfactor=[],
        patch_len=[],
        patch_stride=[],
        no_decomposition=[],
    ):
        super(WPMixerCore, self).__init__()
        self.input_length = input_length
        self.pred_length = pred_length
        self.wavelet_name = wavelet_name
        self.level = level
        self.batch_size = batch_size
        self.channel = channel
        self.d_model = d_model
        self.d_core = d_core
        self.dropout = dropout
        self.embedding_dropout = embedding_dropout
        self.no_decomposition = no_decomposition
        self.tfactor = tfactor
        self.dfactor = dfactor

        self.Decomposition_model = Decomposition(
            input_length=self.input_length,
            pred_length=self.pred_length,
            wavelet_name=self.wavelet_name,
            level=self.level,
            batch_size=self.batch_size,
            channel=self.channel,
            d_model=self.d_model,
            tfactor=self.tfactor,
            dfactor=self.dfactor,
            no_decomposition=self.no_decomposition,
        )

        self.input_w_dim = (
            self.Decomposition_model.input_w_dim
        )  # list of the length of the input coefficient series
        self.pred_w_dim = (
            self.Decomposition_model.pred_w_dim
        )  # list of the length of the predicted coefficient series

        self.patch_len = patch_len
        self.patch_stride = patch_stride

        # (m+1) number of resolutionBranch
        self.resolution_branch = nn.ModuleList(
            [
                ResolutionBranch(
                    input_seq=self.input_w_dim[i],
                    pred_seq=self.pred_w_dim[i],
                    batch_size=self.batch_size,
                    channel=self.channel,
                    d_model=self.d_model,
                    dropout=self.dropout,
                    embedding_dropout=self.embedding_dropout,
                    tfactor=self.tfactor,
                    dfactor=self.dfactor,
                    patch_len=self.patch_len,
                    patch_stride=self.patch_stride,
                )
                for i in range(0, len(self.input_w_dim))
            ]
        )

    def forward(self, xL):
        """
        Parameters
        ----------
        xL : Look back window: [Batch, look_back_length, channel]

        Returns
        -------
        xT : Prediction time series: [Batch, prediction_length, output_channel]
        """
        x = xL.transpose(1, 2)  # [batch, channel, look_back_length]

        # xA: approximation coefficient series,
        # xD: detail coefficient series
        # yA: predicted approximation coefficient series
        # yD: predicted detail coefficient series

        xA, xD = self.Decomposition_model.transform(x)

        yA = self.resolution_branch[0](xA)
        yD = []
        for i in range(len(xD)):
            yD_i = self.resolution_branch[i + 1](xD[i])
            yD.append(yD_i)

        y = self.Decomposition_model.inv_transform(yA, yD)
        y = y.transpose(1, 2)
        xT = y[
            :, -self.pred_length :, :
        ]  # decomposition output is always even, but pred length can be odd

        return xT
    

class FreqLinearLayer(nn.Module):
    """
    A Fourier-based linear layer that operates in the frequency domain. This layer applies the Fast Fourier Transform (FFT)
    to the input time series, selects specific frequency components, performs a complex multiplication using learnable
    weights, and then applies the Inverse Fast Fourier Transform (iFFT) to return to the time domain.

    Parameters:
    ----------
    in_features : int
        Number of input features (channels) in the input time series.
    out_features : int
        Number of output features (channels) for the output time series.
    seq_len : int
        Length of the input sequence (time dimension).
    mode_select_method : str, optional
        Method for selecting which frequency modes to keep. Options are:
        - 'random': Randomly selects a subset of modes.
        - 'lowest': Selects the lowest frequency modes.
        - 'gated': Uses a learnable gating mechanism to select modes. Default is 'random'.
    modes : int, optional
        Number of frequency modes to select. If set to 0, the maximum number of modes (half of the sequence length) is used.

    Methods:
    -------
    _get_frequency_modes(seq_len, modes, mode_select_method):
        Selects the frequency modes based on the provided selection method.
    _compl_mul1d(input, weights_real, weights_imag):
        Performs a complex multiplication in the frequency domain.
    forward(x: torch.Tensor):
        Applies FFT, selects frequency modes, performs complex multiplication, and then applies iFFT to return to the time domain.

    Example Usage:
    -------------
    layer = FourierLinearLayer(in_features=64, out_features=128, seq_len=256, modes=16, mode_select_method='gated')
    output = layer(input_tensor)  # input_tensor should have shape [B, T, I]
    """

    def __init__(
        self, in_features, out_features, seq_len, mode_select_method="random", modes=0
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.seq_len = seq_len
        self.mode_select_method = mode_select_method
        self.sparsity_threshold = 0.01

        max_modes = seq_len // 2 + 1
        if modes == 0 or modes > max_modes:
            modes = max_modes
        self.modes = modes

        self.index = self._get_frequency_modes(seq_len, self.modes, mode_select_method)
        self.num_modes = len(self.index)

        # self.scale = 1 / (in_features * out_features)
        self.scale = 0.02
        self.weights_real = nn.Parameter(
            self.scale * torch.randn(in_features, out_features)
        )
        self.weights_imag = nn.Parameter(
            self.scale * torch.randn(in_features, out_features)
        )
        self.bias_real = nn.Parameter(self.scale * torch.randn(self.out_features))
        self.bias_imag = nn.Parameter(self.scale * torch.randn(self.out_features))
        if mode_select_method == "gated":
            self.gates = nn.Linear(self.seq_len, self.num_modes)

    def _get_frequency_modes(self, seq_len, modes, mode_select_method):
        """
        Selects the frequency modes to use based on the selection method.

        Parameters:
        ----------
        seq_len : int
            Length of the input sequence.
        modes : int
            Number of modes to select.
        mode_select_method : str
            The method for selecting the frequency modes ('random', 'lowest', 'gated').

        Returns:
        -------
        torch.Tensor
            Indices of the selected frequency modes.
        """
        max_modes = seq_len // 2 + 1
        # return torch.arange(max_modes)
        if mode_select_method == "random":
            indices = torch.randperm(max_modes)[:modes]
            indices = indices.sort().values
            return indices
        elif mode_select_method == "lowest":
            return torch.arange(modes)
        else:
            return torch.arange(max_modes)

    def _compl_mul1d(self, input, weights_real, weights_imag):
        """
        Performs complex multiplication in the frequency domain.

        Parameters:
        ----------
        input : torch.Tensor
            The input tensor in the frequency domain with real and imaginary components.
        weights_real : torch.Tensor
            The real part of the learnable weight matrix.
        weights_imag : torch.Tensor
            The imaginary part of the learnable weight matrix.

        Returns:
        -------
        torch.Tensor
            The result of the complex multiplication.
        """
        real_part = F.relu(
            torch.einsum("bfi,io->bfo", input.real, weights_real)
            - torch.einsum("bfi,io->bfo", input.imag, weights_imag)
            + self.bias_real
        )
        # real_part = (
        #     torch.einsum("bfi,io->bfo", input.real, weights_real)
        #     - torch.einsum("bfi,io->bfo", input.imag, weights_imag)
        #     + self.bias_real
        # )

        imag_part = F.relu(
            torch.einsum("bfi,io->bfo", input.real, weights_imag)
            + torch.einsum("bfi,io->bfo", input.imag, weights_real)
            + self.bias_imag
        )
        # imag_part = (
        #     torch.einsum("bfi,io->bfo", input.real, weights_imag)
        #     + torch.einsum("bfi,io->bfo", input.imag, weights_real)
        #     + self.bias_imag
        # )
        out = torch.stack([real_part, imag_part], dim=-1)
        out = F.softshrink(out, lambd=self.sparsity_threshold)
        out = torch.view_as_complex(out)
        # out = torch.complex(real=real_part, imag=imag_part)
        return out

    def forward(self, x: torch.Tensor):
        """
        Forward pass of the FourierLinearLayer. Applies FFT, performs frequency selection,
        complex multiplication, and returns to the time domain via iFFT.

        Parameters:
        ----------
        x : torch.Tensor
            The input tensor with shape [B, T, I] where B is the batch size, T is the sequence length, and I is the input features.

        Returns:
        -------
        torch.Tensor
            The output tensor with shape [B, T, O] where O is the output features.
        """
        B, T, I = x.size()
        x_ft = torch.fft.rfft(x, dim=1, norm="ortho")  # [B, F, I]
        x_ft_selected = x_ft[:, self.index, :]  # [B, num_modes, I]

        if self.mode_select_method == "gated":
            gated = torch.sigmoid(self.gates(x.permute(0, 2, 1))).permute(0, 2, 1)
            x_ft_selected = x_ft_selected * gated

        out_ft = self._compl_mul1d(
            x_ft_selected, self.weights_real, self.weights_imag
        )  # [B, num_modes, O]
        # Initialize the full frequency spectrum with zeros
        out_full_ft = torch.zeros(
            B, T // 2 + 1, self.out_features, dtype=torch.cfloat, device=x.device
        )
        # Place the computed frequencies back into their original positions
        out_full_ft[:, self.index, :] = out_ft
        # Compute the inverse FFT to return to the time domain
        x_out = torch.fft.irfft(out_full_ft, n=T, dim=1, norm="ortho")  # [B, T, O]
        return x_out


class TrendBranch(nn.Module):
    def __init__(self, input_length, pred_length, d_model, d_core, dropout, dfactor, layers):
        super(TrendBranch, self).__init__()
        self.input_length = input_length
        self.pred_length = pred_length
        self.d_model = d_model
        self.d_core = d_core
        self.dropout = dropout
        self.dfactor = dfactor

        self.encoder = Encoder(
            [
                EncoderLayer(
                    GAR(self.d_model, self.d_core),
                    self.d_model,
                    self.d_model * self.dfactor,
                    self.dropout,
                    "gelu",
                )
                for _ in range(layers)
            ],
        )

        self.channel_embedding = DataEmbedding_inverted(
            self.input_length,
            self.d_model,
            self.dropout,
        )
        self.trend_predictor = nn.Linear(self.d_model, self.pred_length, bias=True)

    def forward(self, x):
        # x: [batch, l, c]
        x = self.channel_embedding(x, None)
        x, _ = self.encoder(x, attn_mask=None)
        x = self.trend_predictor(x).transpose(1,2)
        return x


class Model(ForecastModel):
    def _init_model(self, config):
        self.seq_len = config.seq_len
        self.pred_len = config.pred_len
        self.wavelet = config.get("wavelet", "db2")
        self.tfactor = config.get("tfactor", 5)
        self.dfactor = config.get("dfactor", 5)
        self.level = config.get("level", 1)
        self.patch_len = config.patch_len
        self.kernel_size = config.kernel_size
        self.stride = config.get("stride", self.patch_len // 2)
        self.no_decomposition = config.get("no_decomposition", False)
        self.dropout = config.dropout
        self.embedding_dropout = config.get("embedding_dropout", self.dropout)
        self.batch_size = config.batch_size
        self.c_out = config.c_out
        self.d_model = config.d_model
        self.d_core = config.d_core
        self.dropout = config.dropout
        self.d_model_trend = config.d_model_trend
        self.d_ff_trend = config.d_ff_trend
        self.d_core_trend = config.d_core_trend
        self.dropout_trend = config.dropout_trend
        self.dfactor_trend = config.dfactor_trend
        self.layers_trend = config.layers_trend
        self.decomp = weighted_series_decomp(
            kernel_size=self.kernel_size,
            weight_shared=True,
            c_in=config.c_in,
            learnable=True,
            sigma=1.0,
        )

        self.wpmixerCore = WPMixerCore(
            input_length=self.seq_len,
            pred_length=self.pred_len,
            wavelet_name=self.wavelet,
            level=self.level,
            batch_size=self.batch_size,
            channel=self.c_out,
            d_model=self.d_model,
            d_core=self.d_core,
            dropout=self.dropout,
            embedding_dropout=self.embedding_dropout,
            tfactor=self.tfactor,
            dfactor=self.dfactor,
            patch_len=self.patch_len,
            patch_stride=self.stride,
            no_decomposition=self.no_decomposition,
        )

        self.trend_branch = TrendBranch(
            input_length=self.seq_len,
            pred_length=self.pred_len,
            d_model=self.d_model_trend,
            d_core=self.d_core_trend,
            dropout=self.dropout_trend,
            dfactor=self.dfactor_trend,
            layers=self.layers_trend,
        )

    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_season, x_trend = self.decomp(x_enc)

        pred_season = self.wpmixerCore(x_season)
        pred_season = pred_season[:, :, -self.c_out :]

        pred_trend = self.trend_branch(x_trend)

        pred = pred_season + pred_trend

        # De-Normalization
        dec_out = pred * (stdev[:, 0].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out
