import argparse

import optuna
import torch
from omegaconf import OmegaConf
from optuna.visualization import (
    plot_contour,
    plot_optimization_history,
    plot_parallel_coordinate,
    plot_param_importances,
    plot_slice,
)

from main import build_trainer, load_config
from data_provider.datamodules import ForecastDataModule
from models.base import ForecastSolver
import gc

optim_config_path = "configs/optim.yaml"
config_path = "configs/conf.yaml"


def suggest_hparams(trial, config):
    hyperparams = OmegaConf.create({})
    for param_name, param_info in config.items():
        param_type = param_info["type"]
        if param_type == "uniform":
            hyperparams[param_name] = trial.suggest_uniform(
                param_name, param_info["low"], param_info["high"]
            )
        elif param_type == "categorical":
            hyperparams[param_name] = trial.suggest_categorical(
                param_name, param_info["choices"]
            )
        elif param_type == "int":
            hyperparams[param_name] = trial.suggest_int(
                param_name, param_info["low"], param_info["high"]
            )
        elif param_type == "loguniform":
            hyperparams[param_name] = trial.suggest_loguniform(
                param_name, param_info["low"], param_info["high"]
            )
        elif param_type == "float":
            hyperparams[param_name] = trial.suggest_float(
                param_name, param_info["low"], param_info["high"]
            )
        elif param_type == "discrete_uniform":
            hyperparams[param_name] = trial.suggest_discrete_uniform(
                param_name, param_info["low"], param_info["high"], param_info["q"]
            )
        elif param_type == "float_loguniform":
            hyperparams[param_name] = trial.suggest_float(
                param_name, param_info["low"], param_info["high"], log=True
            )
        elif param_type == "float_step":
            hyperparams[param_name] = trial.suggest_float(
                param_name,
                param_info["low"],
                param_info["high"],
                step=param_info["step"],
            )
        else:
            raise ValueError(f"Unsupported parameter type: {param_type}")
    return hyperparams


def objective(trial):
    config = load_config(config_path)
    config.trainer.params.logger = False
    config.save_test_result = False
    config.model_checkpoint.save = False

    optim_config = OmegaConf.load(optim_config_path)

    hparam_conf = suggest_hparams(trial, optim_config)
    config.update(hparam_conf)
    data_module = ForecastDataModule(config)
    solver = ForecastSolver(config)
    trainer = build_trainer(config)
    trainer.fit(model=solver, datamodule=data_module)
    mse = trainer.test(
        model=solver,
        datamodule=data_module,
        ckpt_path="best",
    )[
        0
    ]["mse"]
    del data_module, solver, trainer
    torch.cuda.empty_cache()
    gc.collect()
    return mse


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="config")
    parser.add_argument("--config_path", type=str, default="configs/conf.yaml")
    parser.add_argument("--optim_config_path", type=str, default="configs/optim.yaml")
    parser.add_argument("--n_trials", type=int, default=20)
    parser.add_argument("--direction", type=str, default="minimize")
    parser.add_argument("--n_jobs", type=int, default=1)
    args = parser.parse_args()

    config_path = args.config_path
    optim_config_path = args.optim_config_path

    study = optuna.create_study(direction=args.direction)
    study.optimize(objective, n_trials=args.n_trials, n_jobs=args.n_jobs)

    print("Best trial:")
    trial = study.best_trial
    print(trial.value)
    print(trial.params)
    # # 可视化优化历史并保存为文件
    # opt_history = plot_optimization_history(study)
    # opt_history.write_image("optimization_history.png")
    # # 可视化超参数重要性并保存为文件
    # param_importances = plot_param_importances(study)
    # param_importances.write_image("param_importances.png")
    # # 可视化参数空间的采样并保存为文件
    # slice_plot = plot_slice(study)
    # slice_plot.write_image("slice_plot.png")
    # # 可视化对比多个超参数组合的效果并保存为文件
    # parallel_coordinate = plot_parallel_coordinate(study)
    # parallel_coordinate.write_image("parallel_coordinate.png")
    # # 可视化高维超参数空间的探索并保存为文件
    # contour_plot = plot_contour(study)
    # contour_plot.write_image("contour_plot.png")
    # print("Plots saved to files.")
