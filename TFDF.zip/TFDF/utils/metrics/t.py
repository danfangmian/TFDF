from typing import Any, Union

import torch
import torch.nn as nn
import numpy as np
from torchmetrics import MeanSquaredError

MSELoss = MeanSquaredError


def divide_no_nan(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    # a / b
    result = torch.where(b == 0, torch.zeros_like(a), a / b)
    return result


def weighted_mean(losses: torch.Tensor, weights: torch.Tensor) -> torch.Tensor:
    """
    Compute weighted mean of losses per datapoint.
    """
    return divide_no_nan(torch.sum(losses * weights), torch.sum(weights))


class BasePointLoss(nn.Module):
    def __init__(
        self, horizon_weight: torch.Tensor, outputsize_multiplier, output_names
    ):
        super(BasePointLoss, self).__init__()
        if horizon_weight is not None:
            self.horizon_weight = horizon_weight.float()
        else:
            self.horizon_weight = None
        self.outputsize_multiplier = outputsize_multiplier
        self.output_names = output_names
        self.is_distribution_output = False

    def domain_map(self, y_hat: torch.Tensor) -> torch.Tensor:
        return y_hat.squeeze(-1)

    def _compute_weights(self, y: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        if mask is None:
            mask = torch.ones_like(y, device=y.device)

        if self.horizon_weight is None:
            self.horizon_weight = torch.ones(mask.shape[1], device=y.device)
        if len(self.horizon_weight.shape) == 1:
            assert mask.shape[1] == len(
                self.horizon_weight
            ), "horizon_weight must have same length as the second dimension of Y (L)"
            if len(y.shape) == 2:  # [B, L]
                weights = self.horizon_weight.view(1, -1).expand_as(mask)
            else:  # [B, L, D]
                weights = self.horizon_weight.view(1, -1, 1).expand_as(mask)
        elif len(self.horizon_weight.shape == 2):
            assert (
                mask.shape[1:] == self.horizon_weight.shape
            ), "horizon_weight must match shape of Y (L, D)"
            weights = self.horizon_weight.unsqueeze(0).expand_as(mask)
        else:
            raise ValueError("horizon_weight must be of shape [L] or [L, D]")

        return weights * mask


class MAE(BasePointLoss):
    """Mean Absolute Error"""

    def __init__(self, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ) -> torch.Tensor:
        losses = torch.abs(y - y_hat)
        weights = self._compute_weights(y=y, mask=mask)
        return weighted_mean(losses=losses, weights=weights)


class MSE(BasePointLoss):
    """Mean Squared Error"""

    def __init__(self, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ) -> torch.Tensor:
        losses = (y - y_hat) ** 2
        weights = self._compute_weights(y=y, mask=mask)
        return weighted_mean(losses=losses, weights=weights)


class SignalDecayLoss(BasePointLoss):
    """由CARD算法提出的改进训练损失函数"""

    def __init__(self, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        L = y.shape[1]
        l_weights = torch.tensor(
            [max(1 / np.sqrt(i + 1), 0.0) for i in range(L)], device=y.device
        )
        losses = torch.abs(y - y_hat)

        # 计算损失的加权平均
        if mask is not None:
            weights = self._compute_weights(y=y, mask=mask) * l_weights.view(
                1, -1, 1
            ).expand_as(losses)
        else:
            weights = l_weights.view(1, -1, 1).expand_as(losses)

        return weighted_mean(losses=losses, weights=weights)


class MBE(BasePointLoss):
    """Mean Bias Error"""

    def __init__(self, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ) -> torch.Tensor:
        losses = y - y_hat
        weights = self._compute_weights(y=y, mask=mask)
        return weighted_mean(losses=losses, weights=weights)


class RMSE(BasePointLoss):
    def __init__(self, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        losses = (y - y_hat) ** 2
        weights = self._compute_weights(y=y, mask=mask)
        mse = weighted_mean(losses=losses, weights=weights)
        return torch.sqrt(mse)


class MAPE(BasePointLoss):
    def __init__(self, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        scale = divide_no_nan(torch.ones_like(y, device=y.device), torch.abs(y))
        losses = torch.abs(y - y_hat) * scale
        weights = self._compute_weights(y=y, mask=mask)
        mape = weighted_mean(losses=losses, weights=weights)
        return mape


class SMAPE(BasePointLoss):
    def __init__(self, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        delta_y = torch.abs((y - y_hat))
        scale = torch.abs(y) + torch.abs(y_hat)
        losses = divide_no_nan(delta_y, scale)
        weights = self._compute_weights(y=y, mask=mask)
        return 2 * weighted_mean(losses=losses, weights=weights)


class MASE(BasePointLoss):
    """Mean Absolute Scaled Error"""

    def __init__(self, seasonality: int, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )
        self.seasonality = seasonality

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        y_insample: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        delta_y = torch.abs(y - y_hat)
        scale = torch.mean(
            torch.abs(
                y_insample[:, self.seasonality :] - y_insample[:, : -self.seasonality]
            ),
            axis=1,
        )
        losses = divide_no_nan(delta_y, scale[:, None])
        weights = self._compute_weights(y=y, mask=mask)
        return weighted_mean(losses=losses, weights=weights)


class HuberLoss(BasePointLoss):
    def __init__(self, delta: float = 1.0, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )
        self.delta = delta

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        error = y - y_hat
        is_small_error = torch.abs(error) <= self.delta
        squared_loss = 0.5 * error**2
        linear_loss = self.delta * (torch.abs(error) - 0.5 * self.delta)
        losses = torch.where(is_small_error, squared_loss, linear_loss)
        weights = self._compute_weights(y=y, mask=mask)
        return weighted_mean(losses=losses, weights=weights)


class QuantileLoss(BasePointLoss):
    def __init__(self, quantile: float, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight,
            outputsize_multiplier=1,
            output_names=[f"_ql{quantile}"],
        )
        self.quantile = quantile

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        error = y - y_hat
        losses = torch.max(self.quantile * error, (self.quantile - 1) * error)
        weights = self._compute_weights(y=y, mask=mask)
        return weighted_mean(losses=losses, weights=weights)


class LogCoshLoss(BasePointLoss):
    def __init__(self, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        losses = torch.log(torch.cosh(y_hat - y))
        weights = self._compute_weights(y=y, mask=mask)
        return weighted_mean(losses=losses, weights=weights)


class PoissonLoss(BasePointLoss):
    def __init__(self, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        losses = y_hat - y * torch.log(y_hat)
        weights = self._compute_weights(y=y, mask=mask)
        return weighted_mean(losses=losses, weights=weights)


class TweedieLoss(BasePointLoss):
    def __init__(self, p: float, horizon_weight=None):
        super().__init__(
            horizon_weight=horizon_weight, outputsize_multiplier=1, output_names=[""]
        )
        self.p = p

    def forward(
        self,
        y: torch.Tensor,
        y_hat: torch.Tensor,
        mask: Union[torch.Tensor, None] = None,
    ):
        losses = (
            torch.pow(y, 2 - self.p) / ((1 - self.p) * (2 - self.p))
            - y * torch.pow(y_hat, 1 - self.p) / (1 - self.p)
            + torch.pow(y_hat, 2 - self.p) / (2 - self.p)
        )
        weights = self._compute_weights(y=y, mask=mask)
        return weighted_mean(losses=losses, weights=weights)
