import numpy as np


def mse(actual: np.ndarray, predicted: np.ndarray):
    """Mean Squared Error"""
    return np.mean(np.square(actual - predicted))


def rmse(actual: np.ndarray, predicted: np.ndarray):
    """Root Mean Squared Error"""
    return np.sqrt(mse(actual, predicted))


def mae(actual: np.ndarray, predicted: np.ndarray):
    """Mean Absolute Error"""
    return np.mean(np.abs(actual - predicted))


def mase(
    actual: np.ndarray,
    predicted: np.ndarray,
    history_data: np.ndarray,
    seasonality: int,
):
    """Mean Absolute Scaled Error"""
    if seasonality <= 1:
        raise ValueError("Seasonality must be greater than 1.")
    n = history_data.shape[0]
    d = np.mean(np.abs(history_data[seasonality:] - history_data[:-seasonality]))
    errors = np.abs(actual - predicted)
    return np.mean(errors / d)


def mape(actual: np.ndarray, predicted: np.ndarray, percentage=False):
    """Mean Absolute Percentage Error"""
    # nozero = actual != 0.
    # res = np.mean(np.abs(1 - (predicted[nozero] / actual[nozero])))
    res = np.mean(np.abs(1. - (predicted / actual)))
    return res * 100 if percentage else res


def smape(actual: np.ndarray, predicted: np.ndarray, percentage=False):
    """Symmetric Mean Absolute Percentage Error"""
    denominator = (np.abs(actual) + np.abs(predicted)) / 2.0
    nozero = denominator != 0.0
    res = np.mean(np.abs(actual[nozero] - predicted[nozero]) / denominator[nozero])
    return res * 100 if percentage else res


def wape(actual: np.ndarray, predicted: np.ndarray, percentage=False):
    """Weighted Absolute Percentage Error"""
    res = np.sum(np.abs(actual - predicted)) / np.sum(np.abs(actual))
    return res * 100 if percentage else res


def msmape(actual: np.ndarray, predicted: np.ndarray, percentage=False):
    """Mean Squared Mean Absolute Percentage Error"""
    nozero = actual != 0.0
    res = np.mean(((actual[nozero] - predicted[nozero]) / actual[nozero]) ** 2)
    return res * 100 if percentage else res


def r2(actual: np.ndarray, predicted: np.ndarray):
    """R-squared"""
    ss_res = np.sum((actual - predicted) ** 2)
    ss_tot = np.sum((actual - predicted) ** 2)
    return 1 - (ss_res / ss_tot)


def adj_r2(actual: np.ndarray, predicted: np.ndarray, n, k):
    """Adjusted R-squared"""
    r_2 = r2(actual, predicted)
    return 1 - (1 - r_2) * (n - 1) / (n - k - 1)


def mbd(actual: np.ndarray, predicted: np.ndarray):
    """Mean Bias Deviation"""
    return np.mean(predicted - actual)


def msle(actual: np.ndarray, predicted: np.ndarray):
    """Mean Squared Logarithmic Error"""
    return np.mean((np.log1p(actual) - np.log1p(predicted)) ** 2)


def huber_loss(actual: np.ndarray, predicted: np.ndarray, delta=1.0):
    """Huber Loss"""
    error = actual - predicted
    is_small_error = np.abs(error) <= delta
    squared_loss = np.square(error) / 2
    linear_loss = delta * (np.abs(error) - delta / 2)
    return np.mean(np.where(is_small_error, squared_loss, linear_loss))


def mdae(actual: np.ndarray, predicted: np.ndarray):
    """Median Absolute Error"""
    return np.median(np.abs(actual - predicted))


def quantile_loss(actual: np.ndarray, predicted: np.ndarray, quantile=0.75):
    """Quantile Loss"""
    error = actual - predicted
    return np.mean(np.maximum(quantile * error, (quantile - 1) * error))


def metric(y_true, y_pred, metrics=["mae", "mse"], **kwargs):
    results = {}
    for m in metrics:
        if m in globals():
            func = globals()[m]
            if m == "mase":
                if "y_insample" not in kwargs or "seasonality" not in kwargs:
                    raise ValueError(
                        "y_insample and seasonality are required for MASE calculation"
                    )
                results[m] = func(
                    y_true, y_pred, kwargs["y_insample"], kwargs["seasonality"]
                )
            else:
                results[m] = func(y_true, y_pred)
        else:
            raise ValueError(f"Unknown metric: {m}")
    return results
