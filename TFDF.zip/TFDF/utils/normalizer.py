from typing import Tuple

import torch


def masked_median(
    x: torch.Tensor, mask: torch.Tensor, dim: int = -1, keepdim: bool = True
) -> torch.Tensor:
    """
    计算掩码中值

    计算张量 `x` 在指定维度 `dim` 上的中值，忽略 `mask` 为 False 的值。
    `x` 和 `mask` 需要具有可广播的形状。

    **参数：**<br>
    `x`：torch.Tensor，在 `dim` 维度上计算中值的张量。<br>
    `mask`：torch.Tensor，布尔类型，与 `x` 形状相同，True 表示 `x` 的值有效，False 表示 `x` 的值应被掩盖。掩码在 `dim` 维度的任一列中不应全部为 False，以避免因零除导致的 NaN。<br>
    `dim`（int，可选）：要计算中值的维度。默认为 -1。<br>
    `keepdim`（bool，可选）：是否保持 `x` 的维度。默认为 True。<br>

    **返回：**<br>
    `x_median`：torch.Tensor，包含中值的张量。
    """
    if mask is None:
        x_nan = x.float()
        x_median, _ = x_nan.median(dim=dim, keepdim=keepdim)
    else:
        x_nan = x.float().masked_fill(mask < 1, float("nan"))
        x_median, _ = x_nan.nanmedian(dim=dim, keepdim=keepdim)
        x_median = torch.nan_to_num(x_median, nan=0.0)

    return x_median


def masked_mean(
    x: torch.Tensor, mask: torch.Tensor, dim: int = -1, keepdim: bool = True
) -> torch.Tensor:
    """
    计算掩码均值

    计算张量 `x` 在指定维度 `dim` 上的均值，忽略 `mask` 为 False 的值。
    `x` 和 `mask` 需要具有可广播的形状。

    **参数：**<br>
    `x`：torch.Tensor，在 `dim` 维度上计算均值的张量。<br>
    `mask`：torch.Tensor，布尔类型，与 `x` 形状相同，True 表示 `x` 的值有效，False 表示 `x` 的值应被掩盖。掩码在 `dim` 维度的任一列中不应全部为 False，以避免因零除导致的 NaN。<br>
    `dim`（int，可选）：要计算均值的维度。默认为 -1。<br>
    `keepdim`（bool，可选）：是否保持 `x` 的维度。默认为 True。<br>

    **返回：**<br>
    `x_mean`：torch.Tensor，包含均值的张量。
    """
    if mask is None:
        x_nan = x.float()
        x_mean = x_nan.mean(dim=dim, keepdim=keepdim)
    else:
        x_nan = x.float().masked_fill(mask < 1, float("nan"))
        x_mean = x_nan.nanmean(dim=dim, keepdim=keepdim)
        x_mean = torch.nan_to_num(x_mean, nan=0.0)

    return x_mean


def minmax_statistics(
    x: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6, dim: int = -1
) -> Tuple[torch.Tensor]:
    """
    MinMax 标准化

    通过确保其范围在 [0,1] 之间来标准化时间特征。这种转换通常用作标准化的替代方法。缩放后的特征如下所示：

    $$
    \mathbf{z} = (\mathbf{x}_{[B,T,C]}-\mathrm{min}({\mathbf{x}})_{[B,1,C]})/
        (\mathrm{max}({\mathbf{x}})_{[B,1,C]}- \mathrm{min}({\mathbf{x}})_{[B,1,C]})
    $$

    **参数：**<br>
    `x`：torch.Tensor 输入张量。<br>
    `mask`：torch.Tensor 布尔类型，与 `x` 维度相同，True 表示 `x` 的值有效，False 表示 `x` 的值应被掩盖。掩码在 `dim` 维度的任一列中不应全部为 False，以避免因零除导致的 NaN。默认为 None。<br>
    `eps`（float，可选）：避免除零的小值。默认为 1e-6。<br>
    `dim`（int，可选）：计算最小值和最大值的维度。默认为 -1。<br>

    **返回：**<br>
    `x_min`：torch.Tensor，与 `x` 形状相同，表示输入张量的最小值。<br>
    `x_range`：torch.Tensor，与 `x` 形状相同，表示输入张量的范围。
    """
    if mask is None:
        x_max = torch.max(x, dim=dim, keepdim=True)[0]
        x_min = torch.min(x, dim=dim, keepdim=True)[0]
    else:
        mask = mask.clone()
        mask[mask == 0] = torch.inf
        mask[mask == 1] = 0
        x_max = torch.max(
            torch.nan_to_num(x - mask, nan=-torch.inf), dim=dim, keepdim=True
        )[0]
        x_min = torch.min(
            torch.nan_to_num(x + mask, nan=torch.inf), dim=dim, keepdim=True
        )[0]

    x_max = x_max.type(x.dtype)
    x_min = x_min.type(x.dtype)

    x_range = x_max - x_min
    x_range[x_range == 0] = 1.0
    x_range = x_range + eps

    return x_min, x_range


def minmax_scaler(
    x: torch.Tensor, x_min: torch.Tensor, x_range: torch.Tensor
) -> torch.Tensor:
    return (x - x_min) / x_range


def inv_minmax_scaler(
    z: torch.Tensor, x_min: torch.Tensor, x_range: torch.Tensor
) -> torch.Tensor:
    return z * x_range + x_min


def minmax1_statistics(
    x: torch.Tensor, mask: torch.Tensor = None, eps: float = 1e-6, dim: int = -1
) -> Tuple[torch.Tensor]:
    """MinMax1 标准化

    通过确保其范围在 [-1,1] 之间来标准化时间特征。这种转换通常用作标准化的替代方法或经典的 Min Max Scaler。
    缩放后的特征如下所示：

    $$\mathbf{z} = 2 (\mathbf{x}_{[B,T,C]}-\mathrm{min}({\mathbf{x}})_{[B,1,C]})/ (\mathrm{max}({\mathbf{x}})_{[B,1,C]}- \mathrm{min}({\mathbf{x}})_{[B,1,C]})-1$$

    **参数：**<br>
    `x`：torch.Tensor 输入张量。<br>
    `mask`：torch.Tensor 布尔类型，与 `x` 维度相同，True 表示 `x` 的值有效，False 表示 `x` 的值应被掩盖。掩码在 `dim` 维度的任一列中不应全部为 False，以避免因零除导致的 NaN。默认为 None。<br>
    `eps`（float，可选）：避免除零的小值。默认为 1e-6。<br>
    `dim`（int，可选）：计算最小值和最大值的维度。默认为 -1。<br>

    **返回：**<br>
    `x_min`：torch.Tensor，与 `x` 形状相同，表示输入张量的最小值。<br>
    `x_range`：torch.Tensor，与 `x` 形状相同，表示输入张量的范围。
    """
    if mask is None:
        x_max = torch.max(x, dim=dim, keepdim=True)[0]
        x_min = torch.min(x, dim=dim, keepdim=True)[0]
    else:
        mask = mask.clone()
        mask[mask == 0] = torch.inf
        mask[mask == 1] = 0
        x_max = torch.max(
            torch.nan_to_num(x - mask, nan=-torch.inf), dim=dim, keepdim=True
        )[0]
        x_min = torch.min(
            torch.nan_to_num(x + mask, nan=torch.inf), dim=dim, keepdim=True
        )[0]

    x_max = x_max.type(x.dtype)
    x_min = x_min.type(x.dtype)

    # x_range and prevent division by zero
    x_range = x_max - x_min
    x_range[x_range == 0] = 1.0
    x_range = x_range + eps

    return x_min, x_range


def minmax1_scaler(
    x: torch.Tensor, x_min: torch.Tensor, x_range: torch.Tensor
) -> torch.Tensor:
    x = (x - x_min) / x_range
    z = x * (2) - 1
    return z


def inv_minmax1_scaler(
    z: torch.Tensor, x_min: torch.Tensor, x_range: torch.Tensor
) -> torch.Tensor:
    z = (z + 1) / 2
    return z * x_range + x_min


def std_statistics(
    x: torch.Tensor, mask: torch.Tensor, dim: int = -1, eps: float = 1e-6
) -> Tuple[torch.Tensor]:
    """标准化器

    通过去除均值并按单位方差进行缩放来标准化特征。

    例如，对于 `base_windows` 模型，缩放后的特征如下所示（dim=1）：

    $$\mathbf{z} = (\mathbf{x}_{[B,T,C]}-\\bar{\mathbf{x}}_{[B,1,C]})/\hat{\sigma}_{[B,1,C]}$$

    **参数：**<br>
    `x`：torch.Tensor。<br>
    `mask`：torch.Tensor 布尔类型，与 `x` 维度相同，True 表示 `x` 的值有效，False 表示 `x` 的值应被掩盖。掩码在 `dim` 维度的任一列中不应全部为 False，以避免因零除导致的 NaN。默认为 None。<br>
    `eps`（float，可选）：避免除零的小值。默认为 1e-6。<br>
    `dim`（int，可选）：计算均值和标准差的维度。默认为 -1。<br>

    **返回：**<br>
    `x_means`：torch.Tensor，与 `x` 形状相同，表示输入张量的均值。<br>
    `x_stds`：torch.Tensor，与 `x` 形状相同，表示输入张量的标准差。
    """
    x_means = masked_mean(x=x, mask=mask, dim=dim)
    x_stds = torch.sqrt(masked_mean(x=(x - x_means) ** 2, mask=mask, dim=dim))

    x_stds[x_stds == 0] = 1.0
    x_stds = x_stds + eps
    return x_means, x_stds


def std_scaler(
    x: torch.Tensor, x_means: torch.Tensor, x_stds: torch.Tensor
) -> torch.Tensor:
    return (x - x_means) / x_stds


def inv_std_scaler(
    z: torch.Tensor, x_mean: torch.Tensor, x_std: torch.Tensor
) -> torch.Tensor:
    return (z * x_std) + x_mean


def robust_statistics(
    x: torch.Tensor, mask: torch.Tensor = None, dim: int = -1, eps: float = 1e-6
) -> Tuple[torch.Tensor]:
    """鲁棒中位数缩放器

    通过去除中位数和使用均值绝对偏差（mad）进行缩放来标准化特征。
    这种缩放器在噪声数据中非常有用，因为异常值可能会对样本均值/方差产生负面影响。
    在这些情况下，中位数和mad能够提供更好的结果。

    例如，对于 `base_windows` 模型，缩放后的特征如下所示（dim=1）：

    $$\mathbf{z} = (\mathbf{x}_{[B,T,C]}-\\textrm{median}(\mathbf{x})_{[B,1,C]})/\\textrm{mad}(\mathbf{x})_{[B,1,C]}$$

    $$\\textrm{mad}(\mathbf{x}) = \\frac{1}{N} \sum_{}|\mathbf{x} - \mathrm{median}(x)|$$

    **参数：**<br>
    `x`：torch.Tensor 输入张量。<br>
    `mask`：torch.Tensor 布尔类型，与 `x` 维度相同，True 表示 `x` 的值有效，False 表示 `x` 的值应被掩盖。掩码在 `dim` 维度的任一列中不应全部为 False，以避免因零除导致的 NaN。默认为 None。<br>
    `eps`（float，可选）：避免除零的小值。默认为 1e-6。<br>
    `dim`（int，可选）：计算中位数和mad的维度。默认为 -1。<br>

    **返回：**<br>
    `x_median`：torch.Tensor，与 `x` 形状相同，表示输入张量的中位数。<br>
    `x_mad`：torch.Tensor，与 `x` 形状相同，表示输入张量的均值绝对偏差。
    """

    x_median = masked_median(x=x, mask=mask, dim=dim)
    x_mad = masked_median(x=torch.abs(x - x_median), mask=mask, dim=dim)

    # Protect x_mad=0 values
    # Assuming normality and relationship between mad and std
    x_means = masked_mean(x=x, mask=mask, dim=dim)
    x_stds = torch.sqrt(masked_mean(x=(x - x_means) ** 2, mask=mask, dim=dim))
    x_mad_aux = x_stds * 0.6744897501960817
    x_mad = x_mad * (x_mad > 0) + x_mad_aux * (x_mad == 0)

    # Protect against division by zero
    x_mad[x_mad == 0] = 1.0
    x_mad = x_mad + eps

    return x_median, x_mad


def robust_scaler(
    x: torch.Tensor, x_median: torch.Tensor, x_mad: torch.Tensor
) -> torch.Tensor:
    return (x - x_median) / x_mad


def inv_robust_scaler(
    z: torch.Tensor, x_median: torch.Tensor, x_mad: torch.Tensor
) -> torch.Tensor:
    return z * x_mad + x_median


def invariant_statistics(
    x: torch.Tensor, mask: torch.Tensor, dim: int = -1, eps: float = 1e-6
) -> Tuple[torch.Tensor]:
    """不变中位数缩放器

    通过去除中位数和使用均值绝对偏差（mad）进行缩放来标准化特征。
    此外，还补充了反双曲正弦（arcsinh）变换。

    例如，对于 `base_windows` 模型，缩放后的特征如下所示（dim=1）：

    $$\mathbf{z} = (\mathbf{x}_{[B,T,C]}-\\textrm{median}(\mathbf{x})_{[B,1,C]})/\\textrm{mad}(\mathbf{x})_{[B,1,C]}$$

    $$\mathbf{z} = \\textrm{arcsinh}(\mathbf{z})$$

    **参数：**<br>
    `x`：torch.Tensor 输入张量。<br>
    `mask`：torch.Tensor 布尔类型，与 `x` 维度相同，True 表示 `x` 的值有效，False 表示 `x` 的值应被掩盖。掩码在 `dim` 维度的任一列中不应全部为 False，以避免因零除导致的 NaN。<br>
    `eps`（float，可选）：避免除零的小值。默认为 1e-6。<br>
    `dim`（int，可选）：计算中位数和 mad 的维度。默认为 -1。<br>

    **返回：**<br>
    `z`：torch.Tensor，与 `x` 形状相同，除了进行缩放。
    """
    x_median = masked_median(x=x, mask=mask, dim=dim)
    x_mad = masked_median(x=torch.abs(x - x_median), mask=mask, dim=dim)

    # 保护 x_mad=0 的值
    # 假设正态性和 mad 与标准差之间的关系
    x_means = masked_mean(x=x, mask=mask, dim=dim)
    x_stds = torch.sqrt(masked_mean(x=(x - x_means) ** 2, mask=mask, dim=dim))
    x_mad_aux = x_stds * 0.6744897501960817
    x_mad = x_mad * (x_mad > 0) + x_mad_aux * (x_mad == 0)

    # 防止除以零
    x_mad[x_mad == 0] = 1.0
    x_mad = x_mad + eps
    return x_median, x_mad


def invariant_scaler(
    x: torch.Tensor, x_median: torch.Tensor, x_mad: torch.Tensor
) -> torch.Tensor:
    return torch.arcsinh((x - x_median) / x_mad)


def inv_invariant_scaler(
    z: torch.Tensor, x_median: torch.Tensor, x_mad: torch.Tensor
) -> torch.Tensor:
    return torch.sinh(z) * x_mad + x_median


def identity_statistics(
    x: torch.Tensor, mask: torch.Tensor, dim: int = -1, eps: float = 1e-6
) -> Tuple[torch.Tensor]:
    """恒等缩放器

    作为占位符的恒等缩放器，不受参数影响。

    **参数：**<br>
    `x`：torch.Tensor 输入张量。<br>
    `mask`：torch.Tensor 布尔类型，与 `x` 维度相同，True 表示 `x` 的值有效，False 表示 `x` 的值应被掩盖。掩码在 `dim` 维度的任一列中不应全部为 False，以避免因零除导致的 NaN。<br>
    `eps`（float，可选）：避免除零的小值。默认为 1e-6。<br>
    `dim`（int，可选）：计算中位数和 MAD 的维度。默认为 -1。<br>

    **返回：**<br>
    `x_shift`：原始张量 `x` 的零张量。<br>
    `x_scale`：原始张量 `x` 的一张量。
    """
    # Collapse dim dimension
    shape = list(x.shape)
    shape[dim] = 1

    x_shift = torch.zeros(shape)
    x_scale = torch.ones(shape)

    return x_shift, x_scale


def identity_scaler(
    x: torch.Tensor, x_shift: torch.Tensor, x_scale: torch.Tensor
) -> torch.Tensor:
    return x


def inv_identity_scaler(
    z: torch.Tensor, x_shift: torch.Tensor, x_scale: torch.Tensor
) -> torch.Tensor:
    return z


class TemporalNormalizer:
    """时间序列归一化

    特征标准化是许多机器学习估计器的常见需求，通常通过去除均值和缩放其方差来实现。
    `TemporalNorm` 模块根据归一化类型对输入批次应用时间归一化。

    $$\mathbf{z}_{[B,T,C]} = \\textrm{Scaler}(\mathbf{x}_{[B,T,C]})$$

    如果 `scaler_type` 是 `revin`，则在通常的归一化技术上添加可学习的归一化参数，
    参数通过尺度解耦的全局跳跃连接进行学习。该技术适用于点和概率输出。

    $$\mathbf{\hat{z}}_{[B,T,C]} = \\boldsymbol{\hat{\\gamma}}_{[1,1,C]} \mathbf{z}_{[B,T,C]} +\\boldsymbol{\hat{\\beta}}_{[1,1,C]}$$

    **参数：**<br>
    `scaler_type`: str，定义TemporalNorm使用的归一化类型。可用值[`identity`, `standard`, `robust`, `minmax`, `minmax1`, `invariant`, `revin`]。<br>
    `dim` (int, 可选): 计算缩放和偏移的维度。默认为 -1。<br>
    `eps` (float, 可选): 避免除零的小值。默认为 1e-6。<br>
    """

    def __init__(
        self,
        scaler_type: str = "robust",
        dim: int = -1,
        eps: float = 1e-6,
    ):
        super().__init__()
        compute_statistics = {
            None: identity_statistics,
            "identity": identity_statistics,
            "standard": std_statistics,
            "robust": robust_statistics,
            "minmax": minmax_statistics,
            "minmax1": minmax1_statistics,
            "invariant": invariant_statistics,
        }
        scalers = {
            None: identity_scaler,
            "identity": identity_scaler,
            "standard": std_scaler,
            "robust": robust_scaler,
            "minmax": minmax_scaler,
            "minmax1": minmax1_scaler,
            "invariant": invariant_scaler,
        }
        inv_scalers = {
            None: inv_identity_scaler,
            "identity": inv_identity_scaler,
            "standard": inv_std_scaler,
            "robust": inv_robust_scaler,
            "minmax": inv_minmax_scaler,
            "minmax1": inv_minmax1_scaler,
            "invariant": inv_invariant_scaler,
        }
        assert scaler_type in scalers.keys(), f"{scaler_type} not defined"

        self.compute_statistics = compute_statistics[scaler_type]
        self.scaler = scalers[scaler_type]
        self.inv_scaler = inv_scalers[scaler_type]
        self.scaler_type = scaler_type
        self.dim = dim
        self.eps = eps

    def fit(self, x: torch.Tensor, mask: torch.Tensor):
        x_shift, x_scale = self.compute_statistics(
            x=x,
            mask=mask,
            dim=self.dim,
            eps=self.eps,
        )
        self.x_shift = x_shift
        self.x_scale = x_scale

    def transform(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        assert (
            self.is_fitted
        ), "This normalizer has not fitted yet. Please call fit_transform or fit function first."
        z = self.scaler(x, self.x_shift, self.x_scale)
        return z

    def fit_transform(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        self.fit(x=x, mask=mask)
        z = self.transform(x=x, mask=mask)
        return z

    def inv_transform(self, z: torch.Tensor) -> torch.Tensor:
        assert (
            self.is_fitted
        ), "This normalizer has not fitted yet. Please call fit_transform or fit function first."
        x = self.inv_scaler(z, self.x_shift, self.x_scale)
        return x

    @property
    def is_fitted(self):
        return hasattr(self, "x_shift")
